int main() {
    int x;
    float y;

    y = 32.somerandomstuff56;
    x = 69;

    /*
     * y = You must not print the stuff in the commments
     */

    // Just like I said, Do not print this

    while (x) {
    x = x/2;
    }

    if (x == 0) {
      y = 2;
    }

}
